/// <reference types="vite/client" />
import type { ReactNode } from "react";
import {
  Outlet,
  createRootRoute,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect } from "react";
import Lenis from "@studio-freight/lenis";
import appCss from "../styles/app.css?url";
import Navbar from "../components/Navbar";
import HeaderCustomContent from "../components/HeaderCustomContent";
import Footer from "../components/Footer";

function NotFound() {
  return (
    <div className="flex h-screen items-center justify-center bg-black text-white">
      <h1 className="text-2xl font-bold">404 - Page Not Found</h1>
    </div>
  );
}

function RootComponent() {
  useEffect(() => {
    if (typeof window === "undefined") return;

    const lenis = new Lenis({
      lerp: 0.05, // inertia
      smoothWheel: true,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <RootDocument>
      <Navbar />
      <main className="pt-16">
        <Outlet />
      </main>
      <Footer />
    </RootDocument>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Hidden Dao Martial Arts" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  component: RootComponent,
  notFoundComponent: NotFound,
});

function RootDocument({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
        <HeaderCustomContent />
      </head>
      <body className="relative min-h-screen bg-white text-gray-900 antialiased overflow-hidden">
        {/* Background texture overlay */}
        <div
          className="absolute inset-0 bg-[url('/xuan.png')] bg-repeat opacity-40 pointer-events-none z-0"
          aria-hidden="true"
        />

        {/* Content wrapper */}
        <div id="lenis-root" className="relative z-10">
          {children}
          <Scripts />
        </div>
      </body>
    </html>
  );
}
