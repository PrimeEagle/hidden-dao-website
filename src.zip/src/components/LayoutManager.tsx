type ThreeSlots = {
  slot1: React.ReactNode;
  slot2: React.ReactNode;
  slot3: React.ReactNode;
};

type FourSlots = {
  slot1: React.ReactNode;
  slot2: React.ReactNode;
  slot3: React.ReactNode;
  slot4: React.ReactNode;
};

type LayoutManagerProps =
  | {
      layout: "threeVertical";
      slots: ThreeSlots;
      className?: string;
      height?: string;
    }
  | {
      layout: "threeHorizontal";
      slots: ThreeSlots;
      className?: string;
      height?: string;
    }
  | {
      layout: "twoByTwo";
      slots: FourSlots;
      className?: string;
      rowTemplate?: RowTemplate;
      colTemplate?: ColTemplate;
      height?: string;
    }
  | {
      layout: "leftSpanRightSplit";
      slots: ThreeSlots;
      className?: string;
      rowTemplate?: RowTemplate;
      colTemplate?: ColTemplate;
      height?: string;
    }
  | {
      layout: "rightSpanLeftSplit";
      slots: ThreeSlots;
      className?: string;
      rowTemplate?: RowTemplate;
      colTemplate?: ColTemplate;
      height?: string;
    };

type RowTemplate = "equal" | "split" | "topSmall" | "bottomSmall";
type ColTemplate = "equal" | "leftWide" | "rightWide";

const rowTemplateClasses: Record<RowTemplate, string> = {
  equal: "[grid-template-rows:1fr_1fr]",
  split: "[grid-template-rows:1fr_2fr]",
  topSmall: "[grid-template-rows:1fr_2fr]",
  bottomSmall: "[grid-template-rows:2fr_1fr]",
};

const colTemplateClasses: Record<ColTemplate, string> = {
  equal: "[grid-template-columns:1fr_1fr]",
  leftWide: "[grid-template-columns:2fr_1fr]",
  rightWide: "[grid-template-columns:1fr_2fr]",
};

type CommonProps = {
  className?: string;
  height?: string; // e.g. "h-auto", "h-[800px]"
};

type GridProps = CommonProps & {
  rowTemplate?: RowTemplate;
  colTemplate?: ColTemplate;
};


function LayoutThreeVertical({
  slots,
  className = "",
  height = "h-auto",
}: { slots: ThreeSlots } & CommonProps) {
  return (
    <div className={`flex flex-col gap-2 items-stretch ${height} ${className}`}>
      {slots.slot1}
      {slots.slot2}
      {slots.slot3}
    </div>
  );
}

function LayoutThreeHorizontal({
  slots,
  className = "",
  height = "h-auto",
}: { slots: ThreeSlots } & CommonProps) {
  return (
    <div className={`flex flex-row gap-2 items-stretch ${height} ${className}`}>
      {slots.slot1}
      {slots.slot2}
      {slots.slot3}
    </div>
  );
}

function LayoutTwoByTwo({
  slots,
  className = "",
  rowTemplate = "equal",
  colTemplate = "equal",
  height = "h-auto",
}: { slots: FourSlots } & GridProps) {
  return (
    <div
      className={`grid gap-2 items-stretch ${rowTemplateClasses[rowTemplate]} ${colTemplateClasses[colTemplate]} ${height} ${className}`}
    >
      {slots.slot1}
      {slots.slot2}
      {slots.slot3}
      {slots.slot4}
    </div>
  );
}

function LayoutLeftSpanRightSplit({
  slots,
  className = "",
  rowTemplate = "equal",
  colTemplate = "equal",
  height = "h-auto",
}: { slots: ThreeSlots } & GridProps) {
  return (
    <div
      className={`grid gap-x-2 gap-y-2 items-stretch ${rowTemplateClasses[rowTemplate]} ${colTemplateClasses[colTemplate]} ${height} ${className}`}
    >
      <div className="row-span-2 h-full">{slots.slot1}</div>
      <div className="h-full">{slots.slot2}</div>
      <div className="h-full">{slots.slot3}</div>
    </div>
  );
}

function LayoutRightSpanLeftSplit({
  slots,
  className = "",
  rowTemplate = "equal",
  colTemplate = "equal",
  height = "h-auto",
}: { slots: ThreeSlots } & GridProps) {
  return (
    <div
      className={`grid gap-x-2 gap-y-2 items-stretch ${rowTemplateClasses[rowTemplate]} ${colTemplateClasses[colTemplate]} ${height} ${className}`}
    >
      <div className="h-full">{slots.slot1}</div>
      <div className="row-span-2 h-full">{slots.slot3}</div>
      <div className="h-full">{slots.slot2}</div>
    </div>
  );
}



export default function LayoutManager(props: LayoutManagerProps) {
  switch (props.layout) {
    case "threeVertical":
      return (
        <LayoutThreeVertical
          slots={props.slots}
          className={props.className}
          height={props.height}
        />
      );

    case "threeHorizontal":
      return (
        <LayoutThreeHorizontal
          slots={props.slots}
          className={props.className}
          height={props.height}
        />
      );

    case "twoByTwo":
      return (
        <LayoutTwoByTwo
          slots={props.slots}
          className={props.className}
          rowTemplate={props.rowTemplate}
          colTemplate={props.colTemplate}
          height={props.height}
        />
      );

    case "leftSpanRightSplit":
      return (
        <LayoutLeftSpanRightSplit
          slots={props.slots}
          className={props.className}
          rowTemplate={props.rowTemplate}
          colTemplate={props.colTemplate}
          height={props.height}
        />
      );

    case "rightSpanLeftSplit":
      return (
        <LayoutRightSpanLeftSplit
          slots={props.slots}
          className={props.className}
          rowTemplate={props.rowTemplate}
          colTemplate={props.colTemplate}
          height={props.height}
        />
      );

    default:
      return null;
  }
}