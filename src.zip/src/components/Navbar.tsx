import { motion } from "framer-motion"
import { useActiveSection } from "../hooks/useActiveSection"

const navItems = [
  { id: "hero", label: "Home" },
  { id: "about", label: "About" },
  { id: "styles", label: "Styles" },
  { id: "faq", label: "FAQ" },
  { id: "testimonials", label: "Testimonials" },
  { id: "contact", label: "Contact" },
]

export default function Navbar() {
  const { active, clickSet } = useActiveSection(navItems.map(n => n.id))

  return (
    <nav className="fixed inset-x-0 top-0 z-50 bg-black/80 backdrop-blur">
      <ul className="relative mx-auto flex max-w-5xl justify-center gap-8 px-6 py-4 text-sm font-medium text-brand-softAccent">
        {navItems.map((item) => (
          <li key={item.id} className="relative">
			<a
			  href={`#${item.id}`}
			  onClick={(e) => {
				e.preventDefault()
				const el = document.getElementById(item.id)
				if (el) {
				  el.scrollIntoView({ behavior: "smooth", block: "start" })
				}
				clickSet(item.id)
			  }}
			  className={active === item.id ? "text-white" : "text-white/70"}
			>
			  {item.label}
			</a>
            {active === item.id && (
              <motion.div
                layoutId="nav-underline"
                className="absolute left-0 right-0 -bottom-1 h-0.5 bg-brand-starkAccent"
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            )}
          </li>
        ))}
      </ul>
    </nav>
  )
}
