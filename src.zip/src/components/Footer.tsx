export default function Footer() {
  const year = new Date().getFullYear();
	
  return (
	<footer
	  id="site-footer"
	  className="relative z-10 min-h-40 flex items-center justify-center before:absolute before:top-0 before:left-0 before:w-full before:h-[2px] before:bg-gradient-to-r before:from-transparent before:via-brand-secondary before:to-transparent"
	>
	  <div className="px-4 py-2 bg-brand-light rounded">
	  </div>
	  <div className="mx-auto max-w-7xl px-4 text-center text-sm text-brand-primary">
        <p>&copy; {year} Hidden Dao Martial Arts. All rights reserved.</p>
      </div>
	</footer>
  )
}
