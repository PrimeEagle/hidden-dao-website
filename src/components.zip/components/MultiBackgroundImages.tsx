import FadeImage from "@/components/FadeImage"

type Position = number | string

type BackgroundImage =
  | { src: string; alt: string; top?: Position; bottom?: never; left?: Position; right?: never }
  | { src: string; alt: string; top?: Position; bottom?: never; right?: Position; left?: never }
  | { src: string; alt: string; bottom?: Position; top?: never; left?: Position; right?: never }
  | { src: string; alt: string; bottom?: Position; top?: never; right?: Position; left?: never }

interface BackgroundLayerProps {
  images: BackgroundImage[]
}

function formatPos(value?: Position) {
  if (value === undefined) return ""
  return typeof value === "number" ? `${value}px` : value
}

export default function MultiBackgroundImages({ images }: BackgroundLayerProps) {
  return (
    <div className="absolute inset-0 -z-10">
      {images.map((img, i) => {
        const posClasses = [
          "absolute",
          img.top !== undefined ? `top-[${formatPos(img.top)}]` : "",
          img.bottom !== undefined ? `bottom-[${formatPos(img.bottom)}]` : "",
          img.left !== undefined ? `left-[${formatPos(img.left)}]` : "",
          img.right !== undefined ? `right-[${formatPos(img.right)}]` : "",
          "-translate-x-1/2",
          "-translate-y-1/2",
          "max-w-full"
        ].join(" ")

        return (
          <FadeImage
            key={i}
            src={img.src}
            alt={img.alt}
            className={posClasses}
          />
        )
      })}
    </div>
  )
}